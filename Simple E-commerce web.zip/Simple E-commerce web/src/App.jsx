
import { BrowserRouter } from 'react-router-dom';
import { Routes } from 'react-router-dom';
import { Route } from 'react-router-dom';
import Cart from './components/Cart';
import Navbar from './components/header/Navbar';
import Contact from './components/Contact';
import About from './components/About';

import "./App.css"
import Home from './components/Home';
import { useState } from 'react';

const App = () => {

  const [searchval, setearchval] = useState(null);

  return (
    <div>
      <BrowserRouter>
        <Navbar searchval = {searchval} setearchval={setearchval}/>
        <Routes>
            <Route path="/" element={<Home searchval = {searchval} setearchval={setearchval}/>}/>
            <Route path="/cart" element={<Cart/>}/>
            <Route path="/about" element={<About/>}/>
            <Route path="/contact" element={<Contact/>}/>
        </Routes>
      </BrowserRouter>
    </div>
  );
};

export default App;







