import initialProducts from "../ProductLists";

const Catagoriesbar = ({ searchval, setearchval }) => {

    const newproducts = [
        ...new Set(initialProducts.map((val)=>val.category))
    ]

    const change = (val)=>{
        setearchval(val);
    }
    return (
        <div className="catclass">
            {newproducts.map((val)=>{
                return (
                    <button onClick={()=>change(val)} className="catbtn">{val}</button>
                )
            })}
        </div>
    );
};

export default Catagoriesbar;