import { NavLink } from "react-router-dom";
import SearchBar from "../SearchBar";
import { FaShoppingCart } from "react-icons/fa";
import { FaHome } from "react-icons/fa";
import { FcAbout } from "react-icons/fc";
import { IoIosContact } from "react-icons/io";


const Navbar = ({searchval,setearchval}) => {
  return (
    <nav>
      <div className="navfirst">
        <NavLink onClick={()=>setearchval(null)} to="/" style={{ color: "white" }}>
          <FaHome /><br />
          home
        </NavLink>

        <NavLink to="/about" style={{ color: "white" }}>
          <FcAbout />
          <br />
          About
        </NavLink>

        <NavLink to="/contact" style={{ color: "white" }}>
          <IoIosContact />
          <br />
          Contact
        </NavLink>
      </div>

      <SearchBar searchval = {searchval} setearchval={setearchval}/>

      <div className="navlast">
        <NavLink to="/cart" style={{ color: "white" }}>
          <FaShoppingCart />
          <br />
          Cart
        </NavLink>
      </div>
    </nav>
  );
};

export default Navbar;
