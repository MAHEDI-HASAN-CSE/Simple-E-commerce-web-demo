import initialProducts from "../ProductLists";
import ProductDetails from "./ProductDetails";

const SearchItems = ({ searchval }) => {

  const filteredProducts = initialProducts.filter((itms) => {
    return itms.category.toLowerCase().includes(searchval.toLowerCase());
  });

  const det=()=>{
    <ProductDetails/>
  }

  return (
    <div className="products">
      {filteredProducts.map((itms, index) => {
        
        return(
          <div key={index} className="mar">
            <button onClick={det} className="btn">
              <img src={itms.image} alt="" />
              <h4 style={{color:'black'}}>{itms.category}</h4>
            </button>
          </div>
        )

      })}

    </div>
  );
};

export default SearchItems;
