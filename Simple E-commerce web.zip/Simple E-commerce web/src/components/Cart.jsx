
const Cart = () => {

    return (
        <div>
            handle cart
        </div>
    );
};

export default Cart;