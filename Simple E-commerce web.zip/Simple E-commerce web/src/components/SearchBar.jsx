import { useRef, useState } from "react";

const SearchBar = ({setearchval}) => {
const [search, setsearch] = useState(null);

  const sub=(e)=>{
    e.preventDefault();
    if(search === null)
    {
        src.current.focus();
        return;
    }
    setearchval(search);
  }

  const src = useRef(null);

  return (
    <div>
      <div className="search">
        <form onSubmit={sub}>
          <input
            onChange={(e) => setsearch(e.target.value)}
            ref={src}
            value={search}
            className="inputclass"
            type="text"
            placeholder="Search for products.."
          />
          <button className ="btnclass" type="submit">Search</button>
        </form>
      </div>
    </div>
  );
};

export default SearchBar;
