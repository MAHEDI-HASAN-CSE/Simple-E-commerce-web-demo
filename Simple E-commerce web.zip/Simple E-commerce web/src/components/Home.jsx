import AllProducts from "./AllProducts";
import SearchItems from "./SearchItems";
import Catagoriesbar from './Catagoriesbar';

const Home = ({ searchval, setearchval }) => {



  return (
  <div>
    
    <Catagoriesbar searchval = {searchval} setearchval={setearchval}/>

    {searchval === null ? <AllProducts /> : <SearchItems searchval={searchval}/>}
  </div>
)

};

export default Home;
