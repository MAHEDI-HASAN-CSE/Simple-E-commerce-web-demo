
import initialProducts from './../ProductLists';

const AllProducts = () => {



    return (
        <div className='products'>
            {initialProducts.map((val,index)=>{
                return(
                    <div key={index} className='mar'>
                    <button className='btn'>
                        <img src={val.image} alt="" />
                        <h4 style={{color:'black'}}>{val.category}</h4>
                    </button>
                    </div>
                )
                
            })}
        </div>
    );
};

export default AllProducts;