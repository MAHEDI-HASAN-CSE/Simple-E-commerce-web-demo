import { createContext } from "react";

export const retcontex = createContext();
